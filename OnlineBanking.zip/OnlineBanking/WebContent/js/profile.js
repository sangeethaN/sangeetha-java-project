function doBasicCheck() {
	var name = ids('auth_name'),
		dob = ids('auth_dob'),
		phone = ids('auth_phone'), 
		email = ids('auth_email'),
		proof = ids('auth_proof'),
		gender = names('auth_gender'),
		type = names('account_type');
	if(name.value === "") {
		name.focus();
		alert("Name Can't be empty");
		return false;
	}
	if(dob.value === "") {
		dob.focus();
		alert("DOB can't be empty");
		return false;
	}
	if(phone.value === "") {
		phone.focus();
		alert("Phone Can't be empty");
		return false;
	}
	if(email.value === "") {
		email.focus();
		alert("Email can't be empty");
		return false;
	}
	if(proof.value === "") {
		proof.focus();
		alert("Proof ID Can't be empty");
		return false;
	}
	var i;
	for(i = 0; i < gender.length; i++) {
		if(gender[i].checked)
			break;
	}
	if(i === gender.length) {
		gender[0].focus();
		alert("Select Gender");
		return false;
	}
	for(i = 0; i < type.length; i++) {
		if(type[i].checked)
			break;
	}
	if(i === type.length) {
		type[0].focus();
		alert("Select Account Type");
		return false;
	}
	return doAddressCheck();
}
function doAddressCheck() {
	return addressChecking("comm_", "Communication ") && addressChecking("perm_", "Permanent ");
}
function addressChecking(s, m) {
	var door = ids(s+'door'),
		street = ids(s+'street'),
		location = ids(s+'location'),
		city = ids(s+'city'),
		state = ids(s+'state'),
		country = ids(s+'country'),
		pincode = ids(s+'pincode');
	if(door.value === "") {
		door.focus();
		alert(m+"Door No Can't be empty");
		return false;
	}
	if(street.value === "") {
		street.focus();
		alert(m+"Street Name Can't be empty");
		return false;
	}
	if(location.value === "") {
		location.focus();
		alert(m+"Location Name Can't be empty");
		return false;
	}
	if(city.value === "") {
		city.focus();
		alert(m+"City Name Can't be empty");
		return false;
	}
	if(state.value === "") {
		state.focus();
		alert(m+"State Name Can't be empty");
		return false;
	}
	if(country.value === "") {
		country.focus();
		alert(m+"Country Name Can't be empty");
		return false;
	}
	if(pincode.value === "") {
		pincode.focus();
		alert(m+"Pincode Can't be empty");
		return false;
	}
	return true;
}
function doCopyAddress(t) {
	if(t.checked) {
		if(addressChecking("comm_", "Communication ")) {
			var comm = classs('copy-address'),
				perm = classs('same-address');
			for(var i = 0; i < comm.length; i++) {
				perm[i].value = comm[i].value;
				perm[i].readOnly = true;
			}
		} else {
			t.checked = false;
		}
	} else {
		var all = classs('same-address');
		for(var i = 0; i < all.length; i++) {
			all[i].value = "";
			all[i].readOnly = false;
		}
	}
}
function ids(i) {
	return document.getElementById(i);
}
function names(i) {
	return document.getElementsByName(i);
}
function classs(i) {
	return document.getElementsByClassName(i);
}
function tags(i) {
	return document.getElementByTagName(i);
}