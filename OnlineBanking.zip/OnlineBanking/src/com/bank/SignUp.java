package com.bank;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SignUp
 */
@WebServlet("/requestaccount")
public class SignUp extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SignUp() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try(PrintWriter out=response.getWriter()) {
			try {
				String name = request.getParameter("auth_name");
				String dob = request.getParameter("auth_dob");
				String phone = request.getParameter("auth_phone");
				String email = request.getParameter("auth_email");
				String proof = request.getParameter("auth_proof");
				String gender = request.getParameter("auth_gender");
				String accountType = request.getParameter("account_type");
				String password = request.getParameter("auth_key");
				Integer pin = Integer.valueOf(request.getParameter("auth_pin"));
				String bankingType = request.getParameter("user_type");
				String commDoorNumber = request.getParameter("comm_door");
				String commStreet = request.getParameter("comm_street");
				String commLocation = request.getParameter("comm_location");
				String commCity = request.getParameter("comm_city");
				String commState = request.getParameter("comm_state");
				String commCountry = request.getParameter("comm_country");
				Integer commPincode = Integer.valueOf(request.getParameter("comm_pincode"));
				String permDoorNumber = request.getParameter("perm_door");
				String permStreet = request.getParameter("perm_street");
				String permLocation = request.getParameter("perm_location");
				String permCity = request.getParameter("perm_city");
				String permState = request.getParameter("perm_state");
				String permCountry = request.getParameter("perm_country");
				Integer permPincode = Integer.valueOf(request.getParameter("perm_pincode"));
				Class.forName("oracle.jdbc.driver.OracleDriver");
				Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "secure");
				Statement statement = connection.createStatement();
				ResultSet rs = statement.executeQuery("SELECT ACCOUNT_NO_GENERATOR.NEXTVAL FROM DUAL");
				Long accountNumber = null;
				if(rs.next()) {
					accountNumber = rs.getLong(1);
				}
				rs.close();
				rs = statement.executeQuery("SELECT CUSTOMER_ID_GENERATOR.NEXTVAL FROM DUAL");
				Integer customerId = null;
				if(rs.next()) {
					customerId = rs.getInt(1);
				}
				rs.close();
				PreparedStatement psStmt = connection.prepareStatement("INSERT INTO BANK_PROFILE_TBL VALUES(?,?,?,?,?,?,?,?,?)");
				psStmt.setLong(1, accountNumber);
				psStmt.setString(2, name);
				psStmt.setString(3, dob);
				psStmt.setString(4, phone);
				psStmt.setString(5, email);
				psStmt.setString(6, proof);
				psStmt.setString(7, gender);
				psStmt.setString(8, accountType);
				psStmt.setDouble(9, 500.00);
				psStmt.executeUpdate();
				psStmt = connection.prepareStatement("SELECT TRANSACTION_NO_GENERATOR.NEXTVAL FROM DUAL");
				rs = psStmt.executeQuery();
				String tid = "";
				if(rs.next()) {
					tid = String.format("TID%016d", rs.getLong(1));
				}
				psStmt = connection.prepareStatement("INSERT INTO BANK_TRANSACTION_DETAILS_TBL VALUES(?,?,?,?,?,SYSDATE)");
				psStmt.setLong(1, accountNumber);
				psStmt.setString(2, tid);
				psStmt.setString(3, "deposit");
				psStmt.setDouble(4, 500.00);
				psStmt.setDouble(5, 500.00);
				psStmt.executeUpdate();
				psStmt = connection.prepareStatement("INSERT INTO BANK_TRANSACTION_TBL VALUES(?,?,?,?,?)");
				psStmt.setLong(1, accountNumber);
				psStmt.setInt(2, customerId);
				psStmt.setString(3, password);
				psStmt.setInt(4, pin);
				psStmt.setString(5, bankingType);
				psStmt.executeUpdate();
				psStmt = connection.prepareStatement("INSERT INTO BANK_ADDRESS_TBL VALUES(?,?,?,?,?,?,?,?,?)");
				psStmt.setLong(1, accountNumber);
				psStmt.setString(2, commDoorNumber);
				psStmt.setString(3, commStreet);
				psStmt.setString(4, commLocation);
				psStmt.setString(5, commCity);
				psStmt.setString(6, commState);
				psStmt.setString(7, commCountry);
				psStmt.setInt(8, commPincode);
				psStmt.setString(9, "communication");
				psStmt.executeUpdate();
				psStmt = connection.prepareStatement("INSERT INTO BANK_ADDRESS_TBL VALUES(?,?,?,?,?,?,?,?,?)");
				psStmt.setLong(1, accountNumber);
				psStmt.setString(2, permDoorNumber);
				psStmt.setString(3, permStreet);
				psStmt.setString(4, permLocation);
				psStmt.setString(5, permCity);
				psStmt.setString(6, permState);
				psStmt.setString(7, permCountry);
				psStmt.setInt(8, permPincode);
				psStmt.setString(9, "permanent");
				psStmt.executeUpdate();
				Cookie ck = new Cookie("account_no", ""+accountNumber);
				ck.setMaxAge(60*60);
				response.addCookie(ck);
				ck = new Cookie("customer_id",""+customerId);
				ck.setMaxAge(60*60);
				response.addCookie(ck);
				response.sendRedirect("generated-account.jsp");
			} catch(Exception e) {
				out.println(e);
			}
		}
	}

}
