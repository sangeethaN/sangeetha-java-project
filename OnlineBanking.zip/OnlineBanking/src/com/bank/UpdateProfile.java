package com.bank;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UpdateProfile
 */
@WebServlet("/updateprof")
public class UpdateProfile extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateProfile() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try(PrintWriter out=response.getWriter()) {
			try {
				String name = request.getParameter("auth_name");
				String phone = request.getParameter("auth_phone");
				String email = request.getParameter("auth_email");
				String proof = request.getParameter("auth_proof");
				String gender = request.getParameter("auth_gender");
				String accountType = request.getParameter("account_type");
				String bankingType = request.getParameter("user_type");
				Long accountNumber = Long.valueOf(request.getParameter("accountno"));
				String commDoorNumber = request.getParameter("comm_door");
				String commStreet = request.getParameter("comm_street");
				String commLocation = request.getParameter("comm_location");
				String commCity = request.getParameter("comm_city");
				String commState = request.getParameter("comm_state");
				String commCountry = request.getParameter("comm_country");
				Integer commPincode = Integer.valueOf(request.getParameter("comm_pincode"));
				String permDoorNumber = request.getParameter("perm_door");
				String permStreet = request.getParameter("perm_street");
				String permLocation = request.getParameter("perm_location");
				String permCity = request.getParameter("perm_city");
				String permState = request.getParameter("perm_state");
				String permCountry = request.getParameter("perm_country");
				Integer permPincode = Integer.valueOf(request.getParameter("perm_pincode"));
				Class.forName("oracle.jdbc.driver.OracleDriver");
				Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "secure");
				PreparedStatement psStmt = connection.prepareStatement("UPDATE BANK_PROFILE_TBL SET NAME=?,PHONE_NO=?,EMAIL=?,PROOF_ID=?,GENDER=?,ACCOUNT_TYPE=? WHERE ACCOUNT_NO=?");
				psStmt.setString(1, name);
				psStmt.setString(2, phone);
				psStmt.setString(3, email);
				psStmt.setString(4, proof);
				psStmt.setString(5, gender);
				psStmt.setString(6, accountType);
				psStmt.setLong(7, accountNumber);
				psStmt.executeUpdate();
				psStmt = connection.prepareStatement("UPDATE BANK_ADDRESS_TBL SET DOOR_NUMBER=?,STREET_NAME=?,LOCATION=?,CITY=?,STATE=?,COUNTRY=?,PINCODE=? WHERE ACCOUNT_NO=? AND ADDRESS_TYPE=?");
				psStmt.setString(1, commDoorNumber);
				psStmt.setString(2, commStreet);
				psStmt.setString(3, commLocation);
				psStmt.setString(4, commCity);
				psStmt.setString(5, commState);
				psStmt.setString(6, commCountry);
				psStmt.setInt(7, commPincode);
				psStmt.setLong(8, accountNumber);
				psStmt.setString(9, "communication");
				psStmt.executeUpdate();
				psStmt.setString(1, permDoorNumber);
				psStmt.setString(2, permStreet);
				psStmt.setString(3, permLocation);
				psStmt.setString(4, permCity);
				psStmt.setString(5, permState);
				psStmt.setString(6, permCountry);
				psStmt.setInt(7, permPincode);
				psStmt.setLong(8, accountNumber);
				psStmt.setString(9, "permanent");
				psStmt.executeUpdate();
				response.sendRedirect(bankingType+"/");
			} catch(Exception e) {
				out.println(e);
			}
		}
	}

}
