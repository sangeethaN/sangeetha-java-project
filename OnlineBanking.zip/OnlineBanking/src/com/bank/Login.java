package com.bank;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Login
 */
@WebServlet("/validate")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String user = request.getParameter("auth_user");
		String pass = request.getParameter("auth_key");
		String type = request.getParameter("user_type");
		response.setContentType("text/html");
		try(PrintWriter out=response.getWriter()) {
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "secure");
				PreparedStatement psStmt = connection.prepareStatement("SELECT * FROM BANK_TRANSACTION_TBL WHERE CUSTOMER_ID=? AND PASSWORD=? AND BANKING_TYPE=?");
				psStmt.setString(1, user);
				psStmt.setString(2, pass);
				psStmt.setString(3, type);
				ResultSet rs = psStmt.executeQuery();
				if(rs.next()) {
					Cookie ck = new Cookie("auth_name", rs.getString(2));
					ck.setMaxAge(24 * 60 * 60);
					response.addCookie(ck);
					ck = new Cookie("auth_account", rs.getString(1));
					ck.setMaxAge(24 * 60 * 60);
					response.addCookie(ck);
					ck = new Cookie("auth_user", rs.getString(2));
					ck.setMaxAge(24 * 60 * 60);
					response.addCookie(ck);
					ck = new Cookie("user_type", type);
					ck.setMaxAge(24 * 60 * 60);
					response.addCookie(ck);
					out.println("<meta http-equiv=\"refresh\" content=\"2;url="+type+"/\" /><div class=\"alert alert-success\"><b>Login Success</b> Loading...</div>");
				} else {
					out.println("<link rel=\"stylesheet\" href=\"bootstrap/css/bootstrap.min.css\" type=\"text/css\" /><meta http-equiv=\"refresh\" content=\"3;url=index.html\" /><div style=\"margin:150px;\" class=\"alert alert-danger\"><b>Login Error</b> It will redirect to login jsp file</div>");
				}
			} catch(Exception e) {
				out.println(e);
			}
		}
	}

}