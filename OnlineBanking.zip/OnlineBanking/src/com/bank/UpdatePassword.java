package com.bank;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UpdatePassword
 */
@WebServlet("/updatepass")
public class UpdatePassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdatePassword() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String user = request.getParameter("auth_user");
		String pass = request.getParameter("old_auth_key");
		String newpass = request.getParameter("new_auth_key");
		String type = request.getParameter("user_type");
		response.setContentType("text/html");
		try(PrintWriter out=response.getWriter()) {
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "secure");
				PreparedStatement psStmt = connection.prepareStatement("UPDATE BANK_TRANSACTION_TBL SET PASSWORD=? WHERE CUSTOMER_ID=? AND PASSWORD=? AND BANKING_TYPE=?");
				psStmt.setString(1, newpass);
				psStmt.setInt(2, Integer.valueOf(user));
				psStmt.setString(3, pass);
				psStmt.setString(4, type);
				psStmt.executeUpdate();
				out.println("<meta http-equiv=\"refresh\" content=\"2;url="+type+"/\" /><div class=\"alert alert-success\"><b>Updated</b> Redirecting...</div>");
			} catch(Exception e) {
				out.println(e);
			}
		}
	}

}
